# Lab 11 individual report
Name: Daniel Garcia
NetID: daniel-gar09
Team: 5

## 1. What I personally did in this lab
I ran the Lab 11 chip assembly with my own C1 core macro from Lab 10 (2900 x 4050 um), separate from the team's S submission.
First I checked that most core pins were on the right edge (217 of 346) and ran setup_chip.sh.
I filled the D1 worksheet for H = 4050 um (die 3160 x 4730 um, SRAM row y = 4340 um, met5 keepout top = 4190 um), edited chip/config.yaml, and submitted the assembly run (job 750022, 4:24:57, 80/80 stages).
I then read the signoff results (KLayout DRC 0, Magic DRC 245, LVS match) and the 9-corner timing table, 
and reran the benchmark (PASS, 419 cycles), which gives an achieved period of 52.208 ns (19.15 MHz) and a performance figure of 21.9 us.
Finally, I wrote WAIVERS.md for my core's Lab 10 ff hold violations and made the labeled die shot in KLayout.

## 2. Problems I encountered
Problem 1: The assembly run ended as FAILED.
```
Slurm Job_id=750022 Name=lab11_chip Failed, Run time 04:24:57, FAILED, ExitCode 2
[21:28:58] ERROR    The following error was encountered while running the flow:
                    One or more deferred errors were encountered:
                    245 Magic DRC errors found.
                    4 Magic Illegal Overlap errors found.
                    Hold violations found in the following corners:
                    * max_ss_100C_1v60
```

Problem 2: Magic DRC reported 245 errors.
```
[INFO] COUNT: 245
Error while reading cell "CF_SRAM_1024x32_macro" (byte position 44100): Unknown layer/datatype in boundary, layer=67 type=10
```

Problem 3: The Step 4 KLayout DRC command always printed 0, and my first metrics grep printed nothing.
```
grep '"klayout_drc_error_count"' $(ls -dt chip/runs/RUN_* | head -1)/final/metrics.json
```

Problem 4: Hold violations at max_ss_100C_1v60 on chip input ports.
```
Startpoint: rst (input port clocked by clk)
Endpoint: u_core (rising edge-triggered flip-flop clocked by clk)
                                             -0.129256   slack (VIOLATED)
Startpoint: ext_irq (input port clocked by clk)
Endpoint: u_core (rising edge-triggered flip-flop clocked by clk)
                                             -0.055065   slack (VIOLATED)
```

Problem 5: My core still had ff hold violations from Lab 10.
```
│ max_ff_n40C_1v95     │ -0.0709  │ -0.0709  │ -0.4982  │ 11       │ 11        │
```

Problem 6: Antenna violations at the chip level and inside my core.
```
* Antenna
Failed 𐄂
Pin violations: 1
Net violations: 1
```

## 3. How each problem was resolved
Problem 1: All 80 stages completed and wrote the final views, so the FAILED status came only from deferred checks.
I checked each deferred item separately, and every quality item passes: benchmark PASS, KLayout DRC 0, LVS match, no tt/ss reg-to-reg hold violations, and the die fit inside the frame.
The 4 Magic illegal overlap errors also come from Magic, and since KLayout DRC is 0 and LVS matches, I treated KLayout as the authority, so the chip passes DRC.

Problem 2: The Magic log showed that Magic cannot read the vendor SRAM layers 67, 68, and 69 with datatype 10, so it flagged false violations inside the SRAM macro.
I used KLayout as the independent check, and it reads the same GDS correctly and reports 0.

Problem 3: The TA explained that the Step 4 command counts <item> tags in a JSON file, so it always prints 0.
My grep printed nothing because the real key has double underscores, and with klayout__drc_error__count it printed "klayout__drc_error__count": 0.
The flow log also shows "Check for KLayout DRC errors clear." and "KLayout DRC errors: 0".

Problem 4: Both paths start at chip input ports (rst and ext_irq), and the manual says these come from the default 10 ns I/O constraints, not real silicon risk.
The reg-to-reg column shows 0 violations, and the worst reg-to-reg hold path at max_ss (u_sram_lo.i_sram -> u_core) meets with +1.0392 ns,
so neither fix case applied, and I documented the two paths in D5.

Problem 5: The chip STA cannot see these paths, so I took them from my Lab 10 timing summary.
All 20 violations are ff-only and reg-to-reg, and the worst is -0.0709 ns, within the -0.1 ns limit, so I filled lab11/WAIVERS.md.
For the same endpoint (_607205_), the data required time grows 0.663 ns but the data arrival time grows only 0.596 ns from min_ff to max_ff, so these paths are clock-skew dominated.
The fix would be a Lab 10 rerun with the post-route hold repair turned on, which would take about 17.6 hours including chip reassembly.

Problem 6: The chip-level antenna check found 1 net / 1 pin, and my Lab 10 core still has 3 nets / 3 pins inside the macro.
An antenna violation means a long wire can collect charge during plasma etching and damage the gate oxide it connects to.
Antenna is not on the Lab 12 quality bar, so it does not need a waiver, but in a real tapeout I would fix these with more antenna repair iterations or extra diode insertion.
