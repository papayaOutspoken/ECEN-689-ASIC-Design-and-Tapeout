# Timing Waiver — team 5

These are reg-to-reg hold paths inside the Microwatt core macro from my Lab 10 run (RUN_2026-10-29_13-53-56, macro_kit/timing_summary.rpt).
The Lab 11 chip STA cannot see them because the core .lib models only its interface, and the chip table has no ff hold violations.
Hold passes at every tt and ss corner in Lab 10.

## Violation (max RC)
Corner: max_ff_n40C_1v95
Check: hold
Worst slack (ns): -0.0709
Path count: 11 (all reg-to-reg)
Endpoints (from the timing report): 49-openroad-stapostpnr/max_ff_n40C_1v95/min.rpt
Endpoint	Slack (ns)
_607205_	-0.0709
_607280_	-0.0646
_607269_	-0.0610
_607152_	-0.0491
_607225_	-0.0487
_607162_	-0.0481
_607141_	-0.0438
_607223_	-0.0393
_607237_	-0.0330
_607287_	-0.0321
_607173_	-0.0076

## Violation (nominal RC)
Corner: nom_ff_n40C_1v95
Check: hold
Worst slack (ns): -0.0336
Path count: 8 (all reg-to-reg)
Endpoints (from the timing report): 49-openroad-stapostpnr/nom_ff_n40C_1v95/min.rpt
Endpoint	Slack (ns)
_607205_	-0.0336
_607280_	-0.0256
_607269_	-0.0241
_607225_	-0.0103
_607162_	-0.0103
_607152_	-0.0099
_607141_	-0.0079
_607223_	-0.0010

## Violation (min RC)
Corner: min_ff_n40C_1v95
Check: hold
Worst slack (ns): -0.0039
Path count: 1 (reg-to-reg)
Endpoints (from the timing report): 49-openroad-stapostpnr/min_ff_n40C_1v95/min.rpt
Endpoint	Slack (ns)
_607205_	-0.0039

## Why this corner is not credible for our chip
All three corners are fast transistors ff_n40C_1v95 at 1.95 V and -40 C, with only the wire RC changing.
Our chip would be tested in a lab at room temperature from a 1.80 V supply, which is the tt corner.
At nom_tt_025C_1v80 the core hold worst slack is +0.1574 ns, and the worst tt corner (max_tt_025C_1v80) still passes with +0.0977 ns.
The worst violation (-0.0709 ns) is also within the -0.1 ns waiver limit.
Hold does not depend on clock frequency, so this waiver rests on the operating conditions, not on running the chip slower.

## What we would do with more time
The nom_ff and min_ff endpoints are all among the 11 max_ff endpoints, and hold gets worse as wire RC increases.
From min_ff to max_ff, the data required time of _607205_ grows by 0.663 ns but the data arrival time grows by only 0.596 ns, 
so the extra delay is on the capture clock path and these paths are clock-skew dominated.
The resizer repaired hold after CTS, but routing changed the clock and data delays on these paths, and the post-route repair steps are off by default.
I would rerun the core from global routing with RUN_POST_GRT_RESIZER_TIMING: true, RUN_POST_GRT_DESIGN_REPAIR: true, and GRT_RESIZER_HOLD_SLACK_MARGIN: 0.15.
In Lab 10, routing took 6:35:12 and signoff took 6:37:07 on 8 CPUs, so the rerun would take at least 13.2 hours (about 106 CPU-hours), split into two jobs because of the 12-hour job limit.
Reassembling the chip would add 4:24:57 (about 35 CPU-hours), for a total of about 17.6 hours and 141 CPU-hours.

## Team sign-off
All members have read and agree: Daniel Garcia, Elan Landau, Fidel Omusilibwa, Jinzhan Li, Manoj Kallu, Shivang Bharti
