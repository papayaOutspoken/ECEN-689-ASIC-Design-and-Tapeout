# Lab 11 Individual Report — Fidel Makatia (Team 5)

## 1. What I personally did

I ran Lab 11 from my own account in `~/ASIC_Project/ecen689_lab8`, using my Lab 10
macro (Microwatt config M, 2900 x 4050 um, GDS md5 `e198b56af176757dc8b9d19355e929b8`).

- **Step 0-1:** Unzipped the kit (moved `lab11/` up out of the extra `ecen689_lab11/`
  folder), ran `bash lab11/setup_chip.sh` in a compute-node session (the course drive
  hangs on the login node), checked `chip/macros/corelib/` has all 9 corner libs, and
  confirmed 21 GB free.
- **Step 2 (D1):** Read H = 4050 from `macro_kit/metrics.json`, computed DIE height
  4727 -> 4730, SRAM row y 4340, met5 keepout 4190, and edited the four lines of
  `chip/config.yaml`. Ran the pin-edge check: `{'left': 19, 'right': 211, 'bottom': 89,
  'top': 27}` -> kept SRAM x = 2050 / 2600. Verified the edits before the long run.
- **Step 3 (D2):** Launched assembly run 1 (job 747819), diagnosed its DRC failure,
  applied a chip pin-order fix verified with a short I/O-placement test, and ran
  assembly run 2 (job 751490, `RUN_2026-11-13_02-48-25`, 76/76 steps).
- **Step 4 (D3):** Read KLayout (663), Magic (6962 + 419 overlaps) and LVS
  (`Circuits match uniquely.`), and traced every routing short and KLayout error to a
  single net.
- **Step 5 (D4/D5):** Read the 9-corner table: setup positive everywhere at chip level
  (worst +21.25 ns at max_ss); one hold violation at max_ss (-0.1133 ns) with 0
  reg-to-reg. Achieved period at SS = 50 + 3.6029 (Lab 10 core) = 53.6029 ns, 18.66 MHz.
- **Step 6 (D6/D7):** Reran the benchmark: `BENCHMARK PASS checksum=500 cycles=419`;
  performance figure 419 x 53.6029 = 22,459.6 ns.
- **Step 7 (D8):** Copied `final/render/chip_top.png` and labeled the core, both SRAMs,
  the glue region and the rst/clk pins (`lab11/chip_5.png`).
- Moved the chip runs to shared scratch (with the container bind) when my home quota
  ran low, and preserved run 1's evidence in `lab11/failed_run1/`.

## 2. Problems I encountered

**Problem 1 — tools missing on the login node.**
```
-bash: ghdl: command not found
-bash: lane: command not found
```

**Problem 2 — assembly run 1 failed at signoff.** Job 747819: `FAILED 2:0`, 08:47:44,
error.log:
```
100 Routing DRC errors found. - deferred
6257 Magic DRC errors found. - deferred
696 KLayout DRC errors found. - deferred
502 Magic Illegal Overlap errors found. - deferred
```
Detailed routing ended at `Number of violations = 100`; global routing had
`met1 ... 1 / 0 / 421` overflow; KLayout: `689 m1.2, 5 m1.7, 2 m1.1`.

**Problem 3 — run 2 still not DRC clean.**
```
14 Routing DRC errors found. - deferred
663 KLayout DRC errors found. - deferred
```
All 14: `srcs: inst:u_core net:net721` on met1; KLayout `662 m1.2, 1 m1.7`.

**Problem 4 — home disk space** dropped too low to keep a 3.5 GB run plus a retry.

**Problem 5 — interrupted test run.** My first I/O-placement test printed `Aborted!`
at Verilator lint.

## 3. How they were resolved

**Problem 1:** Same as Lab 10 — the course env.sh only loads on compute nodes, so I ran
`setup_chip.sh`, `lane` tests and `ghdl` inside `srun --qos=olympus-academic --pty bash -i`.
Batch jobs load the environment themselves on their node.

**Problem 2 (main diagnosis):**
1. `chip_top.drc`: all 100 violations were `Short`, all `srcs: inst:u_core net:net714`,
   all on met1 - one net shorting against my core macro.
2. Their bboxes were inside the core, including one met1 wire from x 1607 to 3029.77 at
   y ~2108: the router dragged net714 through the core.
3. The 421 met1 GRT overflow ~= 2900 um / ~6.9 um gcell -> one net crossing the core.
4. I checked for interior signal pins in the core LEF (only VPWR/VGND) - ruled out.
5. Netlist: net714 = `wire714 (buf_12, .A(_000_))` -> `_173_ (dfrtp) .RESET_B`, where
   `_000_ = inv(_072_)` of the reset and `_173_` produces `data_ack`.
6. DEF placements: `wire714` at (110.9, 1833.3) in the LEFT margin; `_173_` and its 3
   antenna diodes at (3050.7, ~1934) in the RIGHT margin. The core blocks met1-met4 and
   met5 is reserved over it, and the net's bounding box was a thin strip across the core,
   so the only path was met1 through the core (KLayout m1.2 spacing along that wire).
7. Root cause: my Lab 10 core has `clk` (core y 4030), `rst` (2628) and the instruction-
   bus control pins (`wb_insn_adr[0..2]`, cyc, stb, ack, stall at core y ~1434-1471) on
   its LEFT edge, while the data-bus pins, SRAMs and SRAM glue are on the right. The
   manual's histogram only showed the majority (211 right).

Fix: a chip pin-order file (`IO_PIN_ORDER_CFG`) putting `rst`/`clk` on the left edge
above the core. I verified it with `lane config.yaml --to Odb.CustomIOPlacement` before
relaunching: rst at (0.3, 4352.3), clk at (0.3, 4459.8), ext_irq/core_run on the right.

**Problem 3:** Same method on run 2: all 14 shorts were `net721`, a met1 wire from
x 131.45 to 3029.77 at y ~2314-2322. Netlist: `wire721 (buf_12, .A(_000_))` ->
`_173_ .RESET_B` - the identical reset -> data_ack-flop path. Moving rst to the top
removed one crossing but the placer still put the long-wire buffer on the left (the
reset tree also serves the boot-ROM glue near the left-edge `wb_insn_*` pins). LVS
matches, setup is positive at all corners and reg-to-reg hold is clean, so the only
remaining defect is this one geometric crossing. Next steps: rst on the right edge (#E)
so the inverter/buffer sit beside `_173_`; robust fallback: re-harden the core with all
`wb_*`/clk/rst on one edge using the manual's pin_order.cfg procedure.

**Problem 4:** `du` showed my lab files were small (macro_kit 1.8 GB, chip run 3.5 GB);
the rest was my research data. I copied `~/chip_runs2` to shared scratch (file counts
1351 = 1351), replaced it with a symlink, and added the container bind line
(`export SINGULARITY_BIND="$SINGULARITY_BIND,/mnt/shared-scratch"; export
APPTAINER_BIND="$SINGULARITY_BIND"`) to `lab11/assemble.sbatch` - the fix I found in
Lab 10. Home went to 16 GB free.

**Problem 5:** `Aborted!` is LibreLane's message for an interrupt; lint is slow because
it reads my 141 MB core netlist. I deleted the aborted run and reran without
interrupting (6:45 to reach I/O placement).
