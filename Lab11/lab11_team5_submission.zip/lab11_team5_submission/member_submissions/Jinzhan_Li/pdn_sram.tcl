# Retain the course's existing standard-cell and core macro grids.
source [file join [file dirname [info script]] pdn_default_course.tcl]

# A specific SRAM grid; the default macro grid remains available for u_core.
define_pdn_grid \
    -macro \
    -name sram_grid \
    -instances {u_sram_lo.i_sram u_sram_hi.i_sram} \
    -starts_with POWER \
    -halo "$::env(PDN_HORIZONTAL_HALO) $::env(PDN_VERTICAL_HALO)"

# SRAM power terminals are on met2.
add_pdn_connect \
    -grid sram_grid \
    -layers "met2 $::env(PDN_VERTICAL_LAYER)"
