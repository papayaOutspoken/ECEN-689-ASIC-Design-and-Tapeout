# Lab 11 Individual Report

Name: Jinzhan Li
NetID: jl90
Team: 5

## 1. What I personally did in this lab

I set up the chip assembly using the Lab 10 Microwatt macro, checked its dimensions and bus-pin locations, and configured the two SRAM macros in the upper-right row. I placed the workspace and run outputs on shared scratch and corrected the container bindings so the compute-node tools could access them. I investigated the SRAM supply connections, added explicit power/ground hooks and an SRAM-specific PDN connection, tested the PDN, and reran the full chip flow. I reran the core benchmark and reviewed the layout checks and nine-corner timing reports, including the inherited Lab 10 core timing. I also opened the final layout in KLayout, exported final ODB placements and the powered netlist for connectivity analysis, and prepared a die image with verified core, SRAM and glue-region labels.

## 2. Problems I encountered

1. **Container access to shared scratch.** The first assembly attempt stopped with:

   Error: Invalid value for '[CONFIG_FILES]...': Path 'config.yaml' does not exist.


   The configuration existed on the host, but the course environment did not initially bind my shared-scratch directory into the container.

2. **Unconnected SRAM supply terminals.** A probe of the first full run's ODB showed the SRAM POWER/GROUND terminals as NET=UNCONNECTED, although design__critical_disconnected_pin__count was zero. Both SRAMs were affected, so the aggregate critical-pin metric alone did not establish that their supplies were connected.

3. **Remaining findings after the PG-fixed full run.** The flow saved final views but exited with deferred errors:

   247 Magic DRC errors found.
   4050 Magic Illegal Overlap errors found.
   Hold violations found in the following corners:
   * max_ss_100C_1v60


   Nonzero maximum-capacitance and maximum-slew counts were reported as warnings.

## 3. How each problem was resolved

1. **Container access to shared scratch.** I first checked chip/config.yaml with ls and readlink -f, which confirmed that the file existed and resolved to the shared-scratch workspace. I then inspected lane and the course environment script. The container bindings included the course directory but not my shared-scratch directory, explaining why the host could see the configuration while the container could not. I appended /mnt/shared-scratch/Yi_S/jl90 to SINGULARITY_BIND after sourcing the environment and entered the physical chip directory. A container preflight then confirmed access to the configuration, referenced files and run directory, and the assembly flow started.

2. **SRAM PDN repair.** Although the critical-disconnected-pin count was zero, I checked the SRAM terminals directly in the first full run's final ODB. The probe showed that the six POWER/GROUND terminals on each SRAM were unconnected. I inspected PDN_MACRO_CONNECTIONS and found an explicit connection for u_core but none for the SRAMs. I also checked the SRAM LEF and found its supply-pin shapes on met2. These results indicated that the SRAMs needed explicit supply-net mappings and a suitable PDN connection to those pins. I retained the vendor wrapper, added the SRAM POWER/GROUND mappings to VPWR and VGND, and added an SRAM-specific PDN grid. I first ran a short test through OpenROAD.GeneratePDN. The grid checks reported all VPWR/VGND shapes connected, and a follow-up ODB probe showed the intended supply-net mappings for both SRAMs. I then reran the full chip flow and checked the mappings in the final powered netlist.

3. **Signoff interpretation and timing.** I read the final flow log and identified three deferred findings: 247 Magic DRC errors, 4050 Magic Illegal Overlap errors and an SS-corner hold violation. I compared these findings with the independent reports. The KLayout JSON contained 257 rule counters with a total of zero violations, Netgen LVS reported Circuits match uniquely, and antenna violations were zero.

   For the Magic overlaps, I inspected the extraction section of the flow log and found that it read the SRAM LEF and chip DEF. The feedback categories were obsm2-metal2 and obsm2-via2. I compared the feedback coordinates with the SRAM met2 pin rectangles after accounting for each macro's placement. All 4050 markers fell within declared pin shapes. This suggests that the overlap findings may be related to how Magic handles the SRAM abstract view and pin connections. I retained the actual counts; further GDS-level checks of the SRAM connections are planned during Lab 12, before the final tapeout freeze.

   For hold timing, I compared the overall hold results with the register-to-register columns in the nine-corner summary. All nine corners had zero register-to-register hold violations. I then inspected the worst SS hold path and found rst -> u_core/rst, with slack of approximately -0.4598 ns and the default 10 ns external input delay. I therefore documented it as the input-port constraint case described in the manual's D5 guidance. Maximum-capacitance and maximum-slew findings remained warnings and were retained in the reports.

