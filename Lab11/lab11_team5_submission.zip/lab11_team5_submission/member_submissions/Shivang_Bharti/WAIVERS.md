# Lab 11 — Timing Exceptions, Team 5

Source chip run: `RUN_2026-11-12_10-34-26`.

## Chip input-port hold entries

| Corner | Path | Slack (ns) |
|---|---|---:|
| nom_ss_100C_1v60 | ext_irq to u_core/ext_irq | -0.018241 |
| max_ss_100C_1v60 | ext_irq to u_core/ext_irq | -0.463534 |
| max_ss_100C_1v60 | rst to u_core/rst | -0.256084 |

The corresponding `55-openroad-stapostpnr/<corner>/min.rpt` files show
10 ns input external delay. These are the chip input-port constraint case
identified in Lab 11 D5, not register-to-register failures. All chip
register-to-register hold violation counts are zero. No chip fast-corner
register-to-register waiver is needed for this table.

## Outstanding core timing

The Lab 10 core has two internal hold violations at max_ff_n40C_1v95,
with worst slack -0.0182 ns. These remain documented; this file does not
assert an approved waiver or team sign-off. A formal waiver would require
the path endpoints, operating-condition justification, and team agreement.

## Physical verification

No waiver is claimed for the 1386 KLayout DRC errors or failed LVS.
The submitted run does not meet the chip signoff gate.
