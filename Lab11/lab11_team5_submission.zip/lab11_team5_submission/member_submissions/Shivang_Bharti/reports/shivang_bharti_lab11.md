# ECEN 689 — Lab 11 Individual Report

**Name:** Shivang Bharti  
**NetID:** shivangbharti  
**Team:** 5

## 1. What I personally did in this lab

I assembled my C4 Microwatt core with two ChipFoundry 1024x32 SRAM macros using the course chip wrapper. I calculated the chip geometry from the 3900 um core height, checked pin placement and macro overlap, and ran assembly with a 50 ns clock target. I inspected the routing, DRC, LVS, and timing reports and investigated why the completed flow returned a failure. I reran the core benchmark, recorded the timing-derived performance figure, and prepared the labeled die image and submission evidence from the same chip run.

## 2. Problems I encountered

Run `RUN_2026-11-12_10-34-26`, job `748500`, reached the final flow stage but exited with status 2 after 08:49:11. Its error log included:

```text
671 Routing DRC errors found. - deferred
12274 Magic DRC errors found. - deferred
1386 KLayout DRC errors found. - deferred
1089 Magic Illegal Overlap errors found. - deferred
6 LVS errors found. - deferred
```

The SRAM import also reported:

```text
Error while reading cell "CF_SRAM_1024x32_macro" (byte position 44100): Unknown layer/datatype in boundary, layer=67 type=10
```

Netgen reported `Top level cell failed pin matching.` The final flow log also reported hold violations at `max_ss_100C_1v60` and `nom_ss_100C_1v60`.

The original Lab 11 KLayout command searched for XML `<item>` tags in a JSON file and could incorrectly report zero errors. The actual final metric was `klayout__drc_error__count: 1386`.

## 3. Diagnosis and outcome

**Geometry and setup:** I used a 3160 x 4580 um die, the core at (130, 130), and SRAMs at (2050, 4190) and (2600, 4190). The rectangles fit without overlap. The core pin histogram was predominantly right-sided, matching the SRAM placement recommended in Lab 11. All nine core timing libraries were present, and the vendor wrapper/controller were unchanged.

**Physical verification:** I checked the actual KLayout metric rather than relying on the defective counting command. The diagnostic supplied with the later lab showed that my Lab 10 core had zero KLayout errors and zero router violations, while 1383 of the chip's 1386 KLayout errors were inside its footprint. Chip nets `delaynet_8_clk` and `net769` crossed the core interior, explaining why a clean core could acquire errors during assembly. LVS showed clock/power-net mismatches consistent with routing shorts. Vendor SRAM import warnings explain why Magic can report artifacts, but they do not excuse the independent KLayout and LVS failures. I retained this run's actual results for Lab 11; no corrective assembly run or clean-signoff result is claimed.

**Timing:** I checked the detailed hold paths. The slow-corner violations start at the chip inputs `ext_irq` and `rst` and use the default 10 ns input delay. Every chip register-to-register hold count is zero, matching the input-constraint case described in Lab 11 D5. The core's two internal fast-corner hold violations from Lab 10 remain documented without an approved waiver.

**Functional result:** The required core benchmark passed with checksum 500 in 419 cycles. Chip setup timing was positive at every corner, but the core's internal SS setup WNS remained -4.2573 ns. The combined achieved period is therefore 50 + 4.2573 = 54.2573 ns, and the performance figure is 419 x 54.2573 = 22733.8087 ns (22.7338087 us).

This run demonstrates successful assembly through report generation, but fails physical signoff. I learned to distinguish flow completion from verification success and to check where chip-level routing interacts with a hardened macro.
