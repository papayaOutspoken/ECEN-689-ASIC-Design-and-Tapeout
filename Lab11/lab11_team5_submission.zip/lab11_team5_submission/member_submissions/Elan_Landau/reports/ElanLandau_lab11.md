# Lab 11 individual report  (copy as reports/<your_name>.md - one per member)
Name: Elan landau
NetID: 237007971
Team: 5

## 1. What I personally did in this lab
<!-- (2-5 sentences. Be specific: which steps you drove, what you typed/read.) -->

Copied lab11 files to olympus.

ran step 1

```
=== chip workspace ready ===
chip:
config.yaml
macros
runs
src

chip/macros:
CF_SRAM_1024x32.gds
CF_SRAM_1024x32.lef
CF_SRAM_1024x32_tt_180V_25C.lib
corelib
microwatt_top.gds
microwatt_top.lef
microwatt_top.nl.v

chip/macros/corelib:
max_ff_n40C_1v95
max_ss_100C_1v60
max_tt_025C_1v80
min_ff_n40C_1v95
NOW: read your core height H from macro_kit/metrics.json (design__die__bbox),
edit the three <-- lines in chip/config.yaml per its worksheet, then launch.

```

Core was $3400$ so total height is $roundup(3400+677,10)=4080$

SRAM y is $3400+290 = 3690$

met4 keepout is $3400 + 140 = 3540$

3166.63 × 4766.63. is larger than core 3160,4080 sizing.

Ran inline script:
```
cd chip && python3 - <<'EOF'
import re
t = open("macros/microwatt_top.lef").read()
W, H = map(float, re.search(r"SIZE +([\d.]+) +BY +([\d.]+)", t).groups())
edges = {"left": 0, "right": 0, "bottom": 0, "top": 0}
for name, body in re.findall(r"PIN (\S+)\n(.*?)END \1", t, re.S):
    m = re.search(r"RECT ([\d.]+) ([\d.]+) ([\d.]+) ([\d.]+)", body)
    if not m: continue
    x = (float(m[1]) + float(m[3])) / 2; y = (float(m[2]) + float(m[4])) / 2
    e = "left" if x < 5 else "right" if x > W - 5 else "bottom" if y < 5 else "top"
    edges[e] += 1
print(edges)
EOF
{'left': 10, 'right': 139, 'bottom': 84, 'top': 113}
```

Most pin right or top, so routing should work.

After that step finishes (fails with magic drc errors)

```
bash-4.4$ R=$(ls -dt chip/runs/RUN_* | head -1)
bash-4.4$ echo $R
chip/runs/RUN_2026-11-13_14-14-14
bash-4.4$ for f in $R/*-klayout-drc/reports/drc.klayout.json; do echo "klayout items: $(grep -c '<item>' $f)"; done
klayout items: 0
bash-4.4$ grep -m1 "COUNT" $R/*-magic-drc/magic-drc.log
[INFO] COUNT: 245
bash-4.4$ grep -m1 -ai "uniquely" $R/*-netgen-lvs/netgen-lvs.log
Circuits match uniquely.
```

bash-4.4$ cat $R/*-openroad-stapostpnr/summary.rpt
┏━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━━┳━━━━━━━━━━┳━━━━━━━━━━━┳━━━━━━━━━━┓
┃                      ┃ Hold     ┃ Reg to   ┃          ┃          ┃ of which  ┃ Setup    ┃           ┃          ┃           ┃ of which ┃           ┃          ┃
┃                      ┃ Worst    ┃ Reg      ┃          ┃ Hold Vio ┃ reg to    ┃ Worst    ┃ Reg to    ┃ Setup    ┃ Setup Vio ┃ reg to   ┃ Max Cap   ┃ Max Slew ┃
┃ Corner/Group         ┃ Slack    ┃ Paths    ┃ Hold TNS ┃ Count    ┃ reg       ┃ Slack    ┃ Reg Paths ┃ TNS      ┃ Count     ┃ reg      ┃ Violatio… ┃ Violati… ┃
┡━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━━╇━━━━━━━━━━╇━━━━━━━━━━━╇━━━━━━━━━━┩
│ Overall              │ -0.3109  │ 0.1646   │ -0.3109  │ 1        │ 0         │ 23.2701  │ 27.5770   │ 0.0000   │ 0         │ 0        │ 37        │ 193      │
│ nom_tt_025C_1v80     │ 0.6018   │ 0.6018   │ 0.0000   │ 0        │ 0         │ 30.7563  │ 38.0484   │ 0.0000   │ 0         │ 0        │ 33        │ 64       │
│ nom_ss_100C_1v60     │ 0.3656   │ 0.6556   │ 0.0000   │ 0        │ 0         │ 24.1490  │ 28.2133   │ 0.0000   │ 0         │ 0        │ 33        │ 175      │
│ nom_ff_n40C_1v95     │ 0.6034   │ 0.6034   │ 0.0000   │ 0        │ 0         │ 33.4768  │ 41.9542   │ 0.0000   │ 0         │ 0        │ 33        │ 42       │
│ min_tt_025C_1v80     │ 0.9054   │ 0.9054   │ 0.0000   │ 0        │ 0         │ 31.3046  │ 38.5889   │ 0.0000   │ 0         │ 0        │ 24        │ 50       │
│ min_ss_100C_1v60     │ 1.0221   │ 1.0841   │ 0.0000   │ 0        │ 0         │ 25.0175  │ 28.9262   │ 0.0000   │ 0         │ 0        │ 24        │ 137      │
│ min_ff_n40C_1v95     │ 0.7811   │ 0.7811   │ 0.0000   │ 0        │ 0         │ 33.8923  │ 42.3546   │ 0.0000   │ 0         │ 0        │ 24        │ 41       │
│ max_tt_025C_1v80     │ 0.2278   │ 0.2278   │ 0.0000   │ 0        │ 0         │ 30.1551  │ 37.5778   │ 0.0000   │ 0         │ 0        │ 37        │ 71       │
│ max_ss_100C_1v60     │ -0.3109  │ 0.1646   │ -0.3109  │ 1        │ 0         │ 23.2701  │ 27.5770   │ 0.0000   │ 0         │ 0        │ 37        │ 193      │
│ max_ff_n40C_1v95     │ 0.4485   │ 0.4485   │ 0.0000   │ 0        │ 0         │ 33.0084  │ 41.6097   │ 0.0000   │ 0         │ 0        │ 37        │ 51       │
└──────────────────────┴──────────┴──────────┴──────────┴──────────┴───────────┴──────────┴───────────┴──────────┴───────────┴──────────┴───────────┴──────────┘

Changed: `GRT_RESIZER_HOLD_SLACK_MARGIN: 0.15`

Didn't change table.

Noticed that the violation is not reg-to-reg so it's actually fine. The violating path is shown below, and appears to be the interrupt request signal.

    5 ======================= max_ss_100C_1v60 Corner ===================================
    6
    7 Startpoint: ext_irq (input port clocked by clk)
    8 Endpoint: u_core (rising edge-triggered flip-flop clocked by clk)
    9 Path Group: clk
   10 Path Type: min
   11
   12 Fanout         Cap        Slew       Delay        Time   Description
   13 ---------------------------------------------------------------------------------------------
   14                                   0.000000    0.000000   clock clk (rise edge)
   15                                   0.000000    0.000000   clock network delay (propagated)
   16                                  10.000000   10.000000 v input external delay
   17      1    0.003429    0.020891    0.010701   10.010701 v ext_irq (in)
   18                                                          ext_irq (net)
   19                       0.020892    0.000000   10.010701 v input1/A (sky130_fd_sc_hd__clkdlybuf4s25_1)
   20      1    0.019067    0.271805    0.570494   10.581195 v input1/X (sky130_fd_sc_hd__clkdlybuf4s25_1)
   21                                                          net1 (net)
   22                       0.271808    0.001367   10.582561 v u_core/ext_irq (microwatt_top)
   23                                              10.582561   data arrival time
   24
   25                                   0.000000    0.000000   clock clk (rise edge)
   26                                   0.000000    0.000000   clock source latency
   27      4    0.217447    1.561608    1.245478    1.245478 ^ clk (in)
   28                                                          clk (net)
   29                       1.589341    0.000000    1.245478 ^ clkbuf_0_clk/A (sky130_fd_sc_hd__clkbuf_16)
   30      2    0.090661    0.186259    0.841527    2.087005 ^ clkbuf_0_clk/X (sky130_fd_sc_hd__clkbuf_16)
   31                                                          clknet_0_clk (net)
   32                       0.187023    0.010814    2.097819 ^ clkbuf_1_0_0_clk/A (sky130_fd_sc_hd__clkbuf_8)
   33      2    0.829288    2.117836    1.446100    3.543918 ^ clkbuf_1_0_0_clk/X (sky130_fd_sc_hd__clkbuf_8)
   34                                                          clknet_1_0_0_clk (net)
   35                       2.385503    0.604258    4.148177 ^ u_core/clk (microwatt_top)
   36                                   0.250000    4.398177   clock uncertainty
   37                                   0.000000    4.398177   clock reconvergence pessimism
   38                                   6.495320   10.893497   library hold time
   39                                              10.893497   data required time
   40 ---------------------------------------------------------------------------------------------
   41                                              10.893497   data required time
   42                                             -10.582561   data arrival time
   43 ---------------------------------------------------------------------------------------------
   44                                              -0.310934   slack (VIOLATED)

Re-ran benchmark
```bash
cd microwatt_src
ghdl -m --std=08 core_tb_course && ghdl -r --std=08 core_tb_course | tee ../lab11/sim_final.log
```

Timing appears fine:
`core_tb_course.vhdl:108:29:@4295ns:(report note): BENCHMARK PASS checksum=500 cycles=419`



## 2. Problems I encountered

1. I thought I had a hold violation issue.

## 3. How each problem was resolved
1. Re-read the manual, noticed that it was not a reg-to-reg so it didn't actually matter.