# ECEN 689 – Lab 11 Individual Report

**Name:** Manoj Kallu  
**Team:** Team 5  
**Run:** `RUN_2026-11-13_01-35-19`

## 1. Work Completed

For Lab 11, I launched the chip assembly run to combine the Microwatt core with the SRAM macros and complete the physical design flow. I monitored the run and reviewed the generated timing, DRC, and LVS reports. I also ran the functional benchmark using GHDL and opened the final GDS in KLayout to inspect the assembled chip layout.

## 2. Design and Run Results

The assembly run was `RUN_2026-11-13_01-35-19`. The flow generated the final GDS file and the rendered chip image.

From the final metrics, the core bounding box was `(5.52, 10.884)` to `(2892.42, 4036.48)`. The core height was calculated as:

`H = 4036.48 - 10.884 = 4025.596 um`

Using the worksheet equations:

- Die height = `H + 577 = 4602.596 um`, rounded up to `4610 um`.
- SRAM row y-position = `H + 190 = 4215.596 um`.
- The required die dimensions are `3160 x 4610 um`.
- These dimensions fit within the available outline of `3166.63 x 4766.63 um`.

## 3. Timing and Functional Verification

The timing summary results:

| Corner group | Hold WNS (ns) | Hold violations | Setup WNS (ns) | Setup violations |
| nom_tt | 1.3090  | 0 | 29.4511 | 0 |
| *_ss   | -0.1354 | 2 | 20.4513 | 0 |
| *_ff   | 0.6106 | 0  | 32.1358 | 0 |

The clock period used for the performance calculation was 50 ns, corresponding to a frequency of 20 MHz.

The functional benchmark completed successfully and reported:

`BENCHMARK PASS checksum=500 cycles=419`

Using the reported cycle count, the total execution time was calculated as:

`419 x 50 ns = 20,950 ns`

## 4. Physical Verification Results

The physical verification reports showed the following results:

- KLayout DRC: 575 items.
- Magic DRC: 4657 errors.
- Magic illegal-overlap errors: 534.
- Routing DRC errors: 378.
- LVS: Circuits match uniquely.

The run log also showed GDS boundary warnings for `CF_SRAM_1024x32_macro` involving layer/datatype values 67, 68, and 69.

The LVS result showed that the circuits matched, but the physical verification reports still contained DRC findings.

## 5. Hold Violations

The `max_ss_100C_1v60` corner reported two hold violations with a worst slack of `-0.1354 ns`.

According to the waiver criteria provided for the lab, the worst slack must be greater than `-0.1 ns` to qualify for a waiver. Since the reported slack is below this limit, the violation does not meet the stated requirement.

## 6. Die Image

I opened the generated `chip_top.gds` file in KLayout and inspected the complete chip layout. The layout view showed the chip boundary, the main core region, and the two SRAM macros near the top of the design.

I saved the screenshot as `manoj_kallu_lab11_chip_team5.png`.

## 7. Files and Evidence

I used the final metrics, timing summary, DRC and LVS reports, and simulation log from my Lab 11 run. I also used the final GDS file in KLayout to inspect the chip layout and saved the screenshot as `manoj_kallu_lab11_chip_team5.png`.

## 8. Conclusion

In this lab, I reviewed the chip assembly flow, timing results, functional benchmark, and physical verification reports. The final GDS was generated, the LVS result showed a unique circuit match, and the functional benchmark passed with a checksum of 500 in 419 cycles.

The timing report showed two hold violations in the slow-slow corner, and the physical verification reports contained DRC findings.