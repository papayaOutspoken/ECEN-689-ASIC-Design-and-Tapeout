# Individual Timing Waiver Report – Team 5

**Name:** Manoj Kallu  
**Run:** `RUN_2026-11-13_01-35-19`

## 1. Timing Violation

- **Corner:** `max_ss_100C_1v60`
- **Check:** Hold
- **Worst Slack:** -0.1354 ns
- **Number of Violations:** 2

The timing report shows two hold violations at the `max_ss_100C_1v60` corner, with a worst slack of -0.1354 ns.

## 2. Waiver Eligibility

According to the waiver criteria provided for this lab, the worst hold slack must be greater than -0.1 ns to qualify for a waiver. Since the reported slack is -0.1354 ns, this violation does not meet the specified requirement.

## 3. Why This Corner Is Not Credible for Our Chip

The hold violations occur at the slow-slow corner with a temperature of 100°C and a supply voltage of 1.60 V. Further review of the operating conditions would be needed to determine whether this corner represents the expected operating conditions of our design.

## 4. What I Would Do With More Time

I would first examine the two violating paths in the detailed timing report and identify their startpoints and endpoints. Based on those paths, I would investigate possible hold-fix options, such as adding delay buffers or performing additional hold repair. I would then rerun the flow to check whether the violations have been resolved.

## 5. Individual Sign-Off

The timing results reported two hold violations. Based on the provided waiver criteria, the worst slack does not qualify for a waiver.
