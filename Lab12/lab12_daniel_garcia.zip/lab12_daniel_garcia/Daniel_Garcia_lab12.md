# Lab 12 individual report
Name: Daniel Garcia
NetID: daniel-gar09
Team: 5

## 1. What I personally did in this lab
I reviewed the log of my frozen core configuration C1 Lab 11 chip run and found that both SRAMs had no power connection,
even though KLayout DRC, LVS, and the benchmark all passed.
Based on those logs, I decided to rerun the chip assembly with the SRAM supply pins mapped to VPWR and VGND,
and with an SRAM power grid added, using the fix a teammate found for our S chip.
Before that, I backed up my run and macro kit to team scratch,
and re-hardened my C1 core from Lab 10 with these lines added at the end of its config.yaml:
```
GRT_ANTENNA_REPAIR_MARGIN: 30
GRT_ANTENNA_REPAIR_ITERS: 10
DRT_ANTENNA_REPAIR_MARGIN: 20
DRT_ANTENNA_REPAIR_ITERS: 10
RUN_POST_GRT_RESIZER_TIMING: true
RUN_POST_GRT_DESIGN_REPAIR: true
GRT_RESIZER_HOLD_SLACK_MARGIN: 0.15
```
The first four give antenna repair a larger margin (default 10) and more passes (default 3)
in global and detailed routing, and the last three turn on timing and design repair
after global routing, with a 0.15 ns hold slack margin.
The new core cut antenna violations from 3 nets to 1 and improved SS setup WNS from -2.208 ns to -1.799 ns,
but hold got worse (44 violations, including one at max_tt), so I split the changes into two experiments.
From the same post-CTS state, I ran core A (only the two DRT antenna lines) and core B (only the last three lines)
in parallel, as chained Slurm jobs with a backup job for the 12-hour limit.
Core A reached 0 antenna violations with 13 ff-only hold violations (worst -0.0631 ns),
and core B was hold clean (worst +0.0698 ns) but kept 6 antenna violations.
I built the SRAM-fixed chip with core A (RUN_2026-11-23_14-16-57), froze it, and filled the Lab 12 checklist with its real outputs.
Over the whole project, my biggest contribution was building a gate-passing C1 chip.

## 2. Problems I encountered
Problem 1: My Lab 11 chip had both SRAMs unpowered.
```
[OpenROAD.GeneratePDN] [PDN-0231] u_sram_hi.i_sram is not connected to any power/ground nets. (and 1 similar warnings)
[OpenROAD.GeneratePDN] [PDN-0189] Supply pin u_sram_hi.i_sram/vnb is not connected to any net. (and 11 similar warnings)
```
Problem 2: In re-run, detailed routing's antenna repair could not clear the last nets.
```
[INFO ANT-0002] Found 2 net violations.
[INFO ANT-0002] Found 2 net violations.
[INFO ANT-0002] Found 2 net violations.
```
Problem 3: The re-hardened core had more hold violations, including one at a typical corner.
```
Hold violations found in the following corners:
* max_ff_n40C_1v95
* max_tt_025C_1v80
* nom_ff_n40C_1v95
│ max_tt_025C_1v80     │ -0.0135  │ -0.0135  │ -0.0135  │ 1        │ 1         │
```

## 3. How each problem was resolved
Problem 1: The template's PDN_MACRO_CONNECTIONS only connected u_core, so I added four lines that map the SRAM pins
vpwrm, vpwra, vpwrp, and vpb to VPWR and vgnd and vnb to VGND, and set PDN_CFG to pdn_sram.tcl,
which keeps the course grid and adds an SRAM grid down to the SRAM met2 pins.
In the new runs the PDN-0231 and PDN-0189 warning count is 0, the grid list includes sram_grid for both SRAMs,
and PSM reports "All shapes on net VPWR are connected." and the same for VGND.

Problem 2: The antenna count dropped from 2556 to 2, so the remaining nets could not be fixed by diodes or jumpers.
The final signoff check reported 1 net (net14167, ratio 1.02, just over the limit), compared with 3 before.
In core A, the 10 detailed-routing passes cleared every net (0 antenna violations),
and the chip built with core A also passes the antenna check.

Problem 3: The hold repair ran after global routing, but detailed routing rerouted large areas
for antenna repair afterwards, which changed the clock and data delays again.
A max_tt violation cannot be waived according to the lab 11 manual (ff-only, worst slack above -0.1 ns),
so I did not use that core and tested the two changes separately.
Core B's post-routing hold repair alone was hold clean at every corner, so hold broke only when both changes ran together.
I used core A, whose 13 ff-only violations (worst -0.0631 ns) are waived in WAIVERS.md.

My worst day was when my core re-run finished.
The routing job had already hit the 12-hour limit once, and after the backup job finished routing,
the signoff results showed that hold had gotten worse, with a max_tt violation that cannot be waived,
so about a day and a half of runs could not be used, and I had to plan the two separate experiments.
What I would redo: test the antenna margin and the post-routing hold repair as separate experiments from the start,
and check the PDN warnings right after the first Lab 11 run.
