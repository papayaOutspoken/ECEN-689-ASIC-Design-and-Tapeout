# FINAL REPORT — Team 5 (C1 chip with core A)

## 1. Design

### Core configuration
Final configuration: C1 (CFG_HAS_FPU = false, ICACHE = 32 lines, DCACHE = 16 lines).
The benchmark program is only 11 instructions at addresses 0x00-0x28, which fits in a single 64-byte cache line,
so after one compulsory instruction-cache miss every instruction fetch was a hit (1 miss and 210 hits in our trace),
and all five configurations we simulated finished in 419 cycles regardless of cache size.
Since C1's flow synthesis area of 4,870,476 um^2 is 16% under the 5,800,000 um^2 limit,
and all three die heights we placed passed detailed placement without errors, C1 carries little risk of a density failure.
Moreover, C1 has a 2 KB instruction cache, which should keep the miss rate low for programs larger than this benchmark.

### Clock
We kept CLOCK_PERIOD = 50 ns (20 MHz) through the whole flow.
The chip STA only sees paths between the core pins, SRAMs, boot ROM, and chip ports, and those meet setup at SS with +17.7618 ns.
The core's internal paths are only in our core A results (runs/C1_expA2), where the worst SS setup slack is -2.2399 ns.
The slowest path sets the clock, so achieved period = 50 + 2.2399 = 52.2399 ns, and frequency = 1000 / 52.2399 = 19.14 MHz.
Hold does not depend on clock frequency, so a slower clock would not remove the ff hold violations in the core.

### Floorplan
The chosen core floorplan is 2900 x 4050 um because it has the lowest utilization of our three placed heights
(3,800, 3,900, and 4,050 um at 44.2%, 43.1%, and 41.5%),
and nearly the same half-perimeter wirelength as the denser runs (21.5 m vs 21.4-21.7 m HPWL).
The clock tree and the 102,683 hold buffers from the post-CTS repair raised the utilization from 50.4% after placement
to 61.3% after CTS, and the core still routed with 0 detailed-routing DRC violations (route__drc_errors 0).

### Core A
Core A uses our chosen Lab 9 C1 placement (2900 x 4050 um). Synthesis through the post-CTS repair ran in RUN_2026-11-20_20-15-56,
and global routing through signoff ran in runs/C1_expA2 with DRT_ANTENNA_REPAIR_ITERS: 10,
which allows up to 10 antenna repair rounds after detailed routing instead of 3.

### Chip worksheet
Core H comes from core A's runs/C1_expA2/final/metrics.json ("design__die__bbox": "0.0 0.0 2900.0 4050.0").

| Worksheet item   | Rule                                            | Value          |
|------------------|-------------------------------------------------|----------------|
| core H           | last number of core A design__die__bbox         | 4050 um        |
| die width        | fixed (frame short edge is 3166.63 um)          | 3160 um        |
| die height       | H + 677, rounded up to the next 10 um           | 4730 um        |
| SRAM row y       | H + 290                                         | 4340 um        |
| met5 keepout top | H + 140                                         | 4190 um        |
| SRAM x           | core pins mostly on the right edge (217 of 346) | 2050 / 2600 um |

Legality: die 3160 x 4730 um inside 3166.63 x 4766.63 um, with 6.63 um to spare in width and 36.63 um in height.

## 2. Results

| Result                  | Value                                                    |
|-------------------------|----------------------------------------------------------|
| die W x H               | 3160 x 4730 um (14.95 mm^2), inside 3166.63 x 4766.63 um |
| achieved SS frequency   | 19.14 MHz (achieved period 52.2399 ns)                   |
| benchmark cycles        | 419 (BENCHMARK PASS checksum=500)                        |
| performance figure      | 419 cycles x 52.2399 ns = 21,888.518 ns = 21.9 us        |
| KLayout DRC / Magic DRC | 0 / 245 (Magic count is a vendor-GDS artifact)           |
| LVS                     | Circuits match uniquely.                                 |
| antenna                 | Passed at the chip level, 0 violating nets in core A     |

### Chip 9-corner table (frozen run summary.rpt, slack in ns)

| corner           | hold WNS | #hold | of which reg-to-reg | setup WNS | #setup |
|------------------|----------|-------|---------------------|-----------|--------|
| nom_tt_025C_1v80 | 0.8495   | 0     | 0                   | 29.2046   | 0      |
| nom_ss_100C_1v60 | 0.5757   | 0     | 0                   | 18.2303   | 0      |
| nom_ff_n40C_1v95 | 0.8028   | 0     | 0                   | 32.6195   | 0      |
| min_tt_025C_1v80 | 1.1599   | 0     | 0                   | 29.3808   | 0      |
| min_ss_100C_1v60 | 1.2913   | 0     | 0                   | 18.7125   | 0      |
| min_ff_n40C_1v95 | 1.0251   | 0     | 0                   | 33.1421   | 0      |
| max_tt_025C_1v80 | 0.4678   | 0     | 0                   | 28.7512   | 0      |
| max_ss_100C_1v60 | -0.1536  | 2     | 0                   | 17.7618   | 0      |
| max_ff_n40C_1v95 | 0.4958   | 0     | 0                   | 31.9925   | 0      |

max_ss_100C_1v60 has 2 hold violations, 0 of them reg-to-reg:
ext_irq -> u_core/ext_irq (-0.1536 ns) and rst -> u_core/rst (-0.0350 ns).
Both start at chip input ports, so they come from the default 10 ns input delay, not a real silicon path,
and the worst reg-to-reg hold path at max_ss meets with +0.9807 ns. Per the manual, they are documented, not waived.

### Core A worst rows (runs/C1_expA2/17-openroad-stapostpnr/summary.rpt, slack in ns)

| corner           | hold WNS | #hold | setup WNS | #setup |
|------------------|----------|-------|-----------|--------|
| nom_tt_025C_1v80 | 0.1726   | 0     | 25.4239   | 0      |
| max_ss_100C_1v60 | 0.6686   | 0     | -2.2399   | 65     |
| max_ff_n40C_1v95 | -0.0631  | 10    | 31.2640   | 0      |

Achieved period at SS = CLOCK_PERIOD + max(0, -SS_setup_WNS) = 50 + max(0, 2.2399) = 52.2399 ns.

### Waivers (lab11/WAIVERS.md)
The chip STA cannot see the core's internal paths, because the core .lib models only its interface,
so the core's ff hold violations come from core A's own signoff.

| corner           | hold WNS | TNS     | path count          | status |
|------------------|----------|---------|---------------------|--------|
| max_ff_n40C_1v95 | -0.0631  | -0.3567 | 10 (all reg-to-reg) | WAIVED |
| nom_ff_n40C_1v95 | -0.0267  | -0.0500 | 3 (all reg-to-reg)  | WAIVED |
| min_ff_n40C_1v95 | +0.0024  | 0.0000  | 0                   | clean  |

Both violating corners are fast transistors ff_n40C_1v95 at 1.95 V and -40 C, with only the wire RC changing.
Our chip would be tested at room temperature from a 1.80 V supply, which is the tt corner,
where core hold passes with +0.1726 ns at nom_tt and +0.1137 ns at max_tt.
The worst violation (-0.0631 ns) is also within the -0.1 ns waiver limit.

### KLayout vs Magic DRC
Magic reports 245 errors, and KLayout reports 0 ("klayout__drc_error__count": 0).
Magic could not read the vendor SRAM layers 67, 68, and 69 with datatype 10,
so it flagged false violations inside the SRAM macro ("Unknown layer/datatype" lines in error.log).
We used KLayout as the independent check, and it reads the same GDS correctly and reports 0.
KLayout is the DRC authority, so the chip passes DRC.

## 3. Journey

### Problem 1 — Both SRAMs unpowered (Lab 11 chip, found in Lab 12)
Symptom: our Lab 11 chip passed KLayout DRC, LVS, and the benchmark, but both SRAMs had no power connection.

Log: the GeneratePDN warnings at the end of the chip flow log of RUN_2026-11-12_17-04-03.
```
[OpenROAD.GeneratePDN] [PDN-0231] u_sram_hi.i_sram is not connected to any power/ground nets. (and 1 similar warnings)
[OpenROAD.GeneratePDN] [PDN-0189] Supply pin u_sram_hi.i_sram/vnb is not connected to any net. (and 11 similar warnings)
```

Fix: the template's PDN_MACRO_CONNECTIONS only connected u_core, so we added four lines that map the SRAM pins
vpwrm, vpwra, vpwrp, and vpb to VPWR and vgnd and vnb to VGND, and set PDN_CFG to pdn_sram.tcl,
which keeps the course grid and adds an SRAM grid down to the SRAM met2 pins.
In the new runs the PDN-0231 and PDN-0189 warning count is 0, the grid list includes sram_grid for both SRAMs,
and PSM reports "All shapes on net VPWR are connected." and the same for VGND.

### Problem 2 — Antenna violations that would not clear (Labs 10-12)
Symptom: the Lab 10 core ended with 3 net / 3 pin antenna violations, and the Lab 11 chip with 1 net / 1 pin.

Log: the manufacturability report at the end of the Lab 10 signoff log.
```
* Antenna
Failed
Pin violations: 3
Net violations: 3
```
In our first re-run, the detailed-routing log printed "[INFO ANT-0002] Found 2 net violations." three rounds in a row,
and the final check still found 1 net (net14167, ratio 1.02, just over the limit).

Fix: we ran from global routing with DRT_ANTENNA_REPAIR_ITERS: 10 as runs/C1_expA2,
which has 0 antenna violations, and the chip built with core A also passes the antenna check,
so the extra repair rounds were what fixed it.

### Problem 3 — ff hold violations, and a re-run that made hold worse (Labs 10-12)
Symptom: the Lab 10 signoff job ended as FAILED after more than 6 hours, even though error.log was empty.

Log: the end of the Lab 10 signoff log, then summary.rpt and the CTS log.
```
Slurm Job_id=738717 Name=lab10_signoff Failed, Run time 06:37:07, FAILED, ExitCode 2
Hold violations found in the following corners:
* max_ff_n40C_1v95
* min_ff_n40C_1v95
* nom_ff_n40C_1v95
```
summary.rpt showed 20 endpoints with a worst hold slack of -0.0709 ns at max_ff_n40C_1v95,
and the CTS log showed "[RSZ-0064] Unable to repair all hold checks within margin." (+0.045 ns against its 0.1 ns margin).
Our first re-run turned on the post-routing hold repair together with stronger antenna repair, and hold got worse:
```
Hold violations found in the following corners:
* max_ff_n40C_1v95
* max_tt_025C_1v80
* nom_ff_n40C_1v95
│ max_tt_025C_1v80     │ -0.0135  │ -0.0135  │ -0.0135  │ 1        │ 1         │
```
That core had 44 hold violations, including one at max_tt, which cannot be waived.

Fix: we split the two changes into parallel experiments from the same post-CTS state, run as chained Slurm jobs.
Core A (antenna lines only) reached 0 antenna violations with 13 ff-only hold violations (worst -0.0631 ns, waivable),
and core B (post-routing hold repair only) was hold clean (worst +0.0698 ns) but kept 6 antenna violations.
Hold broke only when both changes ran together, so we built the chip with core A and waived its ff hold paths.

## 4. Figure
![Labeled die shot: core, both SRAMs, glue logic, die 3160 x 4730 um, team 5](die_annotated.png)