# ECEN 689 — Lab 10 Individual Report

**Name:** Shivang Bharti  
**NetID:** shivangbharti  
**Team:** 5

## 1. What I personally did in this lab

I ran CTS, routing, parasitic extraction, and signoff for my C4 configuration: FPU disabled, 16 instruction-cache lines, and 8 data-cache lines, with a 50 ns clock target and 2900 um die width. I tested heights of 3300, 3650, and 3900 um, investigated failures using stage logs and Slurm status, and restarted interrupted work from saved checkpoints. I reviewed the reference-design reports and my run's clock skew, DRC, LVS, and timing results. I generated the macro kit from the final 3900 um run and documented its provenance and outstanding signoff issues.

## 2. Problems I encountered

### Antenna repair failures at 3300 and 3650 um

Both runs stopped in `35-openroad-repairantennas/1-openroad-diodeinsertion/`, before detailed routing. The exact errors were:

```text
[GRT-0183] Net net55829: heap underflow during 3D maze routing.
[GRT-0183] Net net74376: heap underflow during 3D maze routing.
```

### Time limit during detailed routing at 3900 um

```text
slurmstepd: error: *** JOB 738751 ON n01-zeus CANCELLED AT 2026-11-07T07:22:15 DUE TO TIME LIMIT ***
```

The job reached detailed routing but exceeded its 12-hour allocation. Peak memory was approximately 31.3 GiB, below the 64 GB allocation.

### RC extraction stopped while disk space was exhausted

Job `739394` completed detailed routing but failed at RCX. The filesystem was found full during inspection. RCX logs were empty, so I could not confirm a specific disk-write error from the tool output.

### Deferred hold failure at signoff

```text
Hold violations found in the following corners:
* max_ff_n40C_1v95
```

Job `741900` generated final views but returned exit code 2. The timing report showed two hold violations with worst slack -0.0182 ns. The run's `error.log` was empty despite this failure.

## 3. How each problem was resolved

**Antenna repair:** Following the manual's guidance, I treated congestion as the working diagnosis and increased height from 3300 to 3650 um. The same failure persisted, so I increased height by another 250 um to 3900 um, keeping the cache configuration and clock target unchanged. The 3900 um run passed antenna repair and completed routing. The result supports using the larger floorplan for this configuration, but does not prove the underlying cause of the heap error.

**Time limit:** I checked Slurm accounting to distinguish a timeout from a memory failure. I restarted detailed routing from the prior completed stage using `lab10/resume_detailed_to_rcx.sbatch`, avoiding another synthesis, placement, and CTS run.

**RCX interruption:** After freeing disk space, I used `lab10/resume_rcx.sbatch` to start extraction from the saved pre-RCX state. Job `741877` completed nominal, minimum, and maximum SPEF extraction.

**Signoff:** I compared the scheduler result with the flow log and timing summary rather than treating an empty `error.log` as proof of success. Magic DRC reported `COUNT: 0`, KLayout DRC passed, and LVS reported `Circuits match uniquely.` The two fast-corner hold violations remain documented for the Lab 11 waiver discussion; two antenna pin/net violations and slew/capacitance warnings also remain. Macro extraction preserved these qualifications in the kit's status and provenance files.

## Final results and lesson

The final run, `RUN_2026-11-06_19-22-15`, uses a 2900 x 3900 um die. CTS inserted 10,147 buffers; post-CTS nominal setup and hold skew were 0.532425 ns and -1.07285 ns. Worst SS setup slack after routing was -4.2573 ns, giving an achieved period of **54.2573 ns**, approximately **18.43 MHz**, by the lab's calculation.

My Lab 9 report predicted successful routing at 3300 um. After that failed, I expected 3650 um to be a better routing choice, but only 3900 um completed routing and extraction. I learned that placement completion and lower utilization do not guarantee routability, and that completed routing, physical verification, and timing closure are separate results.
