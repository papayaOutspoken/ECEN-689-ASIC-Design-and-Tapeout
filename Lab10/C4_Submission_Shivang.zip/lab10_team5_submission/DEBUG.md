# ECEN 689 Lab 10 — Debugging Record

**Team:** 5  
**Configuration:** C4; FPU disabled, 16 instruction-cache lines, 8 data-cache lines.  
**Die width:** 2900 um. **Clock period:** 50 ns. **Final height:** 3900 um.

## 3300 um: antenna repair failure

Run: `RUN_2026-10-28_19-02-45`; job `735740`.

```text
[GRT-0183] Net net55829: heap underflow during 3D maze routing.
```

Failing step: `35-openroad-repairantennas/1-openroad-diodeinsertion/`.
The failure occurred after jumper and diode insertion, before detailed
routing. Following the lab manual, congestion was treated as the working
diagnosis; the error alone does not establish the underlying cause.

**Change:** increase height to 3650 um and run
`sbatch lab10/refloorplan_to_rcx.sbatch`, retaining C4 and the 50 ns target.
This increase was 350 um rather than the manual's suggested 250 um.

## 3650 um: antenna repair failure

Run: `RUN_2026-11-06_09-38-12`; job `738093`.

```text
[GRT-0183] Net net74376: heap underflow during 3D maze routing.
```

Failing step: `35-openroad-repairantennas/1-openroad-diodeinsertion/`.
The same failure persisted at 3650 um.

**Change:** increase height by 250 um to 3900 um and rerun the same script.

## 3900 um: routing and extraction

Run: `RUN_2026-11-06_19-22-15`.

- Job `738751` passed antenna repair but reached the 12-hour limit in
  `37-openroad-detailedrouting`.
- Job `739394` restarted detailed routing from the prior saved stage and
  completed routing, then failed at RCX. The filesystem was found full;
  empty RCX logs prevented confirmation of a specific disk-write error.
- After freeing space, job `741877` started RCX from
  `47-odb-cellfrequencytables/state_out.json` and completed extraction.
  `49-openroad-rcx/state_out.json` and all three SPEF corner files exist.

**Result:** routing and RC extraction completed at 3900 um.

## Signoff

Job `741900` completed the final flow stages and generated final views,
but returned exit code 2 because of a deferred hold-check failure:

```text
Hold violations found in the following corners:
* max_ff_n40C_1v95
```

Failing checker: `68-checker-holdviolations`. Evidence:
`flow_signoff_macro_741900.log` and `50-openroad-stapostpnr/summary.rpt`.
The run's `error.log` is empty despite this deferred error.

| Check | Result |
|---|---|
| Magic DRC | `COUNT: 0` |
| KLayout DRC | Passed |
| LVS | `Circuits match uniquely.` |
| Hold | 2 violations at max_ff_n40C_1v95; worst slack -0.0182 ns |
| Antenna | 2 violating pins and 2 violating nets |
| Slew/capacitance | Warnings remain |
| Worst SS setup slack | -4.2573 ns |
| Achieved period | 50 + 4.2573 = 54.2573 ns |

The fast-corner hold violations are documented for the Lab 11 waiver
discussion; no waiver has been approved.

## Macro extraction

`bash lab10/extract_macro.sh` generated `macro_kit/` from the final views.
The copied design files were verified against their sources. Provenance
and outstanding signoff issues are recorded in `PROVENANCE.txt` and
`SIGNOFF_STATUS.txt`.
