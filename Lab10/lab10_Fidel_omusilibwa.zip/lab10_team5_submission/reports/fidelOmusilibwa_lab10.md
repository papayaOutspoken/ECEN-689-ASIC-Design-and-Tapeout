# Lab 10 Individual Report — Fidel Makatia (Team 5)

## 1. What I personally did

I ran the Lab 10 flow from my own account, in `~/ASIC_Project/ecen689_lab8`, on our
chosen Lab 9 run `RUN_2026-10-28_18-36-01` (config M 32/32, 2900 x 4050 um,
CLOCK_PERIOD 50 ns), and read all tool output myself.

- **Step 0 / pre-flight:** Unzipped the kit (it extracted into an extra
  `ecen689_lab10/` folder, so I moved `lab10/` and `LAB10_MANUAL.md` up one level and
  confirmed the seven files with `ls lab10`). Verified `config.yaml` still had
  `DIE_AREA: [0, 0, 2900, 4050]` and the cache lines at 32. Moved the three non-chosen
  Lab 9 runs out of `runs/` so `--last-run` could only find the 4050 run, and freed home
  space (25 GB free).
- **Step 1 (CTS):** Launched CTS, diagnosed a 12 h timeout (Problem 3), fixed it and
  relaunched (job 735964, COMPLETED 0:0, 6:45:02). C1: `Total number of Buffers
Inserted: 13917.`; worst setup skew 0.518 ns, worst hold skew -0.946 ns (nom_tt).
- **Step 2 (reference run):** From a compute node, read the staff run's reports:
  met1 was the busiest layer (0.32% usage, 0 overflow on all layers); antenna
  violations 21 nets / 26 pins before repair and 0 / 0 after; total wirelength
  57,175 um.
- **Step 3 (routing):** Launched routing from the post-CTS state (job 737141).
  Global routing: 0 overflow on every layer (total 53.83%, met2 68.60%); detailed
  routing ended with `Number of violations = 0`. The job then failed in RCX on a full
  disk (Problem 4), which I fixed and reran (job 738426, COMPLETED 0:0, SPEF present).
- **Step 4 (C5/C6):** error.log empty, last step `46-openroad-rcx`,
  `microwatt_top.nom.spef` present. Our B9 prediction ("will route") was correct.
- **Step 5 (signoff):** Job 738452 COMPLETED 0:0 in 6:44:06:
  `[INFO] COUNT: 0`, `Circuits match uniquely.`, error.log empty.
- **Step 6 (C9):** Read `summary.rpt`: no hold violations at any corner (worst
  +0.0159 ns at max_ff); setup positive at TT/FF, worst SS setup -3.6029 ns
  (max_ss_100C_1v60, 53 paths). Achieved period at SS = 50 + 3.6029 = **53.6029 ns**
  (~18.7 MHz).
- **Step 7 (C10):** Ran `bash lab10/extract_macro.sh`; `macro_kit/` has the GDS
  (1003M), LEF, netlist, SDC, lib/, spef/, metrics.json, timing summary and
  PROVENANCE.txt (GDS md5 `e198b56af176757dc8b9d19355e929b8`).
- Wrote `lab10/DEBUG.md` documenting both failures (C7).

## 2. Problems I encountered

**Problem 1 — course environment hung on the login node.**
`source /mnt/nfs-scratch/ecen-689-nowka/kit/env.sh` never returned (Ctrl-C did not
help), and afterwards:

```
/usr/bin/which: no lane in (...)
/usr/bin/which: no ghdl in (...)
```

**Problem 2 — first CTS launch failed immediately.** After I moved `~/chip_runs` to
shared scratch with a symlink (to save home space), job 734859 ended in seconds:

```
[18:10:14] ERROR    The flow has encountered an unexpected error:
                    last_run used without any existing runs
```

**Problem 3 — CTS hit the 12 h time limit (main problem).**

```
slurmstepd: error: *** JOB 734863 ON n03-poseidon CANCELLED AT 2026-11-05T06:14:36 DUE TO TIME LIMIT ***
```

`sacct`: TIMEOUT 12:00:06 with 8 CPUs. The post-CTS repair was crawling:

```
170 | ... | -295.689
210 | ... | -275.801   (TNS -8374752.5, 67127 endpoints, _658535_/D)
```

**Problem 4 — routing job failed at RCX on a full disk.** Job 737141: `FAILED 1:0`
after 06:50:40, stopped in `46-openroad-rcx`, and

```
coe-fs.engr.tamu.edu:/ifs/home/Grads   50G   50G     0 100% /home/grads
```

**Problem 5 — first RCX rerun failed with a read-only error.** Job 738305:

```
OSError: [Errno 30] Read-only file system: '/mnt/nfs-scratch'
```

## 3. How they were resolved

**Problem 1:** I opened an interactive compute-node session
(`srun --qos=olympus-academic --pty bash -i`) and the same `source` printed
`ECEN 689 ready.` and defined `lane`/`ghdl`. So only the login node's mount of the course
drive was stuck. Batch jobs run on compute nodes and load env.sh there, so I kept
submitting from the login node and did tool work in srun sessions.

**Problem 2:** The error meant LibreLane found no runs. The flow runs inside a
Singularity container, which by default only sees my home and the course share, so
`runs -> ~/chip_runs -> /mnt/shared-scratch/...` was a dead link inside it. Since home
then had 25 GB free (meeting the manual's 20 GB), I copied the run back into a real
`~/chip_runs` folder (365 files, same count as the scratch copy) and relaunched.

**Problem 3:** I worked from symptoms to cause:

1. `sacct` showed 8 CPUs, so it was not a CPU-count issue; skew was 0.39-0.46 ns, so
   not the clock.
2. The worst path in `30-openroad-stamidpnr-1/max.rpt` was only 8.0 ns of logic, then
   `_384813_/Y (nor2_2)` driving fanout 8120 / 28.4 pF with 1789 ns slew and 3935 ns
   delay -> slack -4655 ns; checks.rpt had 521,492 slew violations.
3. But step 25 (post-GPL design repair) said `Inserted 86651 buffers in 7367 nets`
   and `Remaining 0`. To resolve the contradiction I counted references to that net
   (`_159883_`) in each step's netlist: 8122 (synthesis) -> 4 (step 25) -> 4 (step 27)
   -> 8122 (CTS). So CTS was working on an unbuffered netlist.
4. `29-openroad-cts/state_in.json` pointed to `19-openroad-ioplacement` instead of
   `27-openroad-detailedplacement`. CTS had resumed from a pre-placement,
   pre-repair state. The likely trigger was the extra `28-klayout-opengui` step left in
   the run by Lab 9's KLayout viewing.

Fix: moved steps 28-31 to `~/lab10_failed_cts/`, confirmed `lane` supports
`--with-initial-state`, and relaunched CTS starting explicitly from step 27's
`state_out.json` (`lab10/to_cts_fixed.sbatch`). I verified the new CTS `state_in`
pointed at step 27 before waiting on it. Job 735964 completed in 6:45. I used the same
explicit-state safeguard for routing (step 30) and signoff (step 46) and verified
`state_in` each time.

**Problem 4:** Detailed routing had already finished with 0 violations, so only RCX
needed rerunning. `du -sh` showed the run at 9.4 GB. I removed the partial RCX folder,
copied the run to my shared-scratch area (verified file counts), replaced `~/chip_runs`
with a symlink, and confirmed `runs/` still listed the run. This freed the home quota
(back to 25 GB). To avoid Problem 2 again, I first tested that the container could see
scratch with `SINGULARITY_BIND` before launching. RCX was then run alone with
`--with-initial-state .../45-odb-cellfrequencytables/state_out.json --from OpenROAD.RCX
--to OpenROAD.RCX`.

**Problem 5:** The traceback came from `ciel` trying to create the PDK directory,
meaning the PDK was not visible in the container. `grep BIND env.sh` showed
`export SINGULARITY_BIND="/var/tmp/$USER,$ECEN689_SHARE"`, and my script line had
replaced that list with only `/mnt/shared-scratch`, hiding the PDK. I changed it to
append and set `APPTAINER_BIND` to the same full list (Apptainer prefers that variable):

```
export SINGULARITY_BIND="$SINGULARITY_BIND,/mnt/shared-scratch"; export APPTAINER_BIND="$SINGULARITY_BIND"
```

In an srun session I confirmed the bind list was
`/var/tmp/fidelmakatia,/mnt/nfs-scratch/ecen-689-nowka,/mnt/shared-scratch` and that
the container could list both `$PDK_ROOT` (`ciel`) and the run directory. RCX job 738426
then completed in 3:56 with all three SPEFs, and signoff passed with DRC 0 and LVS match.
