# Lab 10 DEBUG — Fidel Makatia

All runs, diagnosis and fixes below were done by me from my account (fidelmakatia).

Design: Microwatt config M (ICACHE 32 / DCACHE 32, FPU off), DIE_AREA 2900 x 4050 um,
CLOCK_PERIOD 50 ns. Run: RUN_2026-10-28_18-36-01 (chosen Lab 9 placement run).

I hit two failures this week. I diagnosed both, fixed with one change each, and
relaunched each to a clean finish (CTS -> routing -> RCX -> signoff -> macro_kit).

---

## Failure 1: CTS hit the 12 h time limit

### First error line
```
slurmstepd: error: *** JOB 734863 ON n03-poseidon CANCELLED AT 2026-11-05T06:14:36 DUE TO TIME LIMIT ***
```

### Step dir
`runs/RUN_2026-10-28_18-36-01/31-openroad-resizertimingpostcts`

- `sacct -j 734863`: TIMEOUT, Elapsed 12:00:06, AllocCPUS 8 (full allocation, so not a CPU-count problem)
- `error.log` empty (job was killed, not failed)
- 29-openroad-cts and 30-openroad-stamidpnr-1 had completed

### Evidence
Post-CTS repair loop, last rows (iteration | ... | WNS):
```
170 | ... | -295.689
210 | ... | -275.801   (TNS -8374752.5, 67127 violating endpoints, worst pin _658535_/D)
```
Worst post-CTS path (30-openroad-stamidpnr-1/max.rpt, nom_tt): arrival is 8.0 ns until
two high-fanout nets:
```
_384811_/X (o22a_2): fanout 4423,  17.9 pF, slew   88 ns, delay   60 ns
_384813_/Y (nor2_2): fanout 8120,  28.4 pF, slew 1789 ns, delay 3935 ns
-> data arrival 4708.4 ns vs required 52.9 ns -> slack -4655.45 ns
```
checks.rpt: max slew violation count 521,492 (worst = _384813_/Y and its loads).

Post-GPL design repair (25-openroad-repairdesignpostgpl) HAD fixed these nets:
`Inserted 86651 buffers in 7367 nets`, final row `Remaining 0`.

Net `_159883_` (output of `_384813_`) reference count in each step's netlist:
```
01-yosys-vhdlsynthesis        8122   (unbuffered)
25-openroad-repairdesignpostgpl  4   (buffered)
27-openroad-detailedplacement    4   (buffered)
29-openroad-cts               8122   (unbuffered again)
```
State files:
```
29-openroad-cts/state_in.json -> 19-openroad-ioplacement/microwatt_top.{odb,nl.v}
27-openroad-detailedplacement/state_out.json -> 27-openroad-detailedplacement/microwatt_top.{odb,nl.v}
```

### Diagnosis
CTS resumed from the wrong state. `lane --last-run --from OpenROAD.CTS` loaded the state of
19-openroad-ioplacement (before global placement and before design repair) instead of
27-openroad-detailedplacement. CTS and post-CTS timing repair therefore ran on an unplaced,
unbuffered netlist (8120-fanout net, 1.8 us slew, WNS -4655 ns). repair_timing fixes setup
path by path and cannot rebuild an 8k-fanout net, so it improved ~2 ns per 10 iterations and
hit the 12 h limit. Likely trigger: the extra `28-klayout-opengui` step (added when the run
was opened in KLayout for Lab 9 Step 5) in the run directory confused the resume's state
selection.

Not the cause (checked): CPU count (8 allocated), clock skew (0.39-0.46 ns), cache config
(design repair buffered the same nets successfully), floorplan.

### The ONE fix applied
Moved steps 28-31 out of the run (to ~/lab10_failed_cts/ as evidence) and relaunched CTS
starting explicitly from the buffered placement state:
```
lane config.yaml --last-run \
  --with-initial-state runs/RUN_2026-10-28_18-36-01/27-openroad-detailedplacement/state_out.json \
  --from OpenROAD.CTS --to OpenROAD.ResizerTimingPostCTS
```
(lab10/to_cts_fixed.sbatch)

### Relaunch result
- Job 735964: COMPLETED 0:0, 06:45:02. Verified new CTS state_in = 27-openroad-detailedplacement.
- CTS: `Total number of Buffers Inserted: 13917.`; worst setup skew 0.518 ns, worst hold skew -0.946 ns (nom_tt).
- Post-CTS repair finished (final row +0.061, area +17.6%); warning `RSZ-0064 Unable to repair all hold checks within margin` (no hold violations at signoff).
- Routing was launched with the same safeguard: `--with-initial-state .../30-openroad-resizertimingpostcts/state_out.json` (verified state_in).

---

## Failure 2: home disk full during RCX

### First error line
Routing job 737141: `FAILED 1:0`, Elapsed 06:50:40, stopped in 46-openroad-rcx while writing
SPEF for 3 corners. `df -h ~`:
```
coe-fs.engr.tamu.edu:/ifs/home/Grads   50G   50G     0 100% /home/grads
```

### Step dir
`runs/RUN_2026-10-28_18-36-01/46-openroad-rcx` (run directory 9.4 GB)

### Diagnosis
Routing itself completed cleanly:
- Global routing: 0 overflow on all layers (total usage 53.83%, met2 68.60%, met1 60.30%)
- Detailed routing: `Number of violations = 0` (final iteration)

The home quota filled when RCX wrote parasitics for nom/min/max. Not a routing or congestion
failure.

### The ONE fix applied
Moved the run off the home quota and reran RCX only:
1. Removed the partial 46-openroad-rcx.
2. Copied the run to `/mnt/shared-scratch/Silva-Martinez_J/fidelmakatia/chip_runs`
   (file counts verified equal) and replaced `~/chip_runs` with a symlink to it.
3. Made scratch visible inside the flow container by appending it to env.sh's bind list
   (after `source env.sh`):
   ```
   export SINGULARITY_BIND="$SINGULARITY_BIND,/mnt/shared-scratch"; export APPTAINER_BIND="$SINGULARITY_BIND"
   ```
4. Ran RCX only:
   ```
   lane config.yaml --last-run \
     --with-initial-state runs/RUN_2026-10-28_18-36-01/45-odb-cellfrequencytables/state_out.json \
     --from OpenROAD.RCX --to OpenROAD.RCX
   ```
   (lab10/rcx_only.sbatch)

Intermediate attempt: job 738305 failed with
`OSError: [Errno 30] Read-only file system: '/mnt/nfs-scratch'` because the first version of
the export REPLACED env.sh's `SINGULARITY_BIND="/var/tmp/$USER,$ECEN689_SHARE"` instead of
appending to it, hiding the PDK. Fixed by appending (above); verified inside the container
that both `$PDK_ROOT` and the run directory were visible before resubmitting.

### Relaunch result
- RCX job 738426: COMPLETED 0:0, 00:03:56; `46-openroad-rcx/nom/microwatt_top.nom.spef` (plus min/max) present; error.log empty.
- Signoff job 738452 (lab10/signoff_fixed.sbatch, same bind + `--with-initial-state .../46-openroad-rcx/state_out.json`): COMPLETED 0:0, 06:44:06.
  - `[INFO] COUNT: 0`
  - `Circuits match uniquely.`
  - error.log empty
- macro_kit extracted; `PROVENANCE.txt` lists the scratch run path
  (`/mnt/shared-scratch/Silva-Martinez_J/fidelmakatia/chip_runs/RUN_2026-10-28_18-36-01`)
  because of this relocation. GDS md5 `e198b56af176757dc8b9d19355e929b8`.

---

## Open items after clean signoff (warnings, not failures)

These did not fail signoff (DRC COUNT 0, LVS match, error.log empty) but I recorded them
for Lab 11/12.

### 1. Antenna: 10 nets / 12 pins remain
`38-openroad-checkantennas-1/openroad-checkantennas-1.log`:
```
[INFO ANT-0002] Found 10 net violations.
[INFO ANT-0001] Found 12 pin violations.
```
(down from 6158 nets / 8112 pins in 32-openroad-checkantennas, before diode repair).
warning.log: `[GRT-0243] Unable to repair antennas on net with diodes.`

All are side-area ratio violations (limit 400). Nets: `_152741_` (2 pins),
`core_0.loadstore1_0.m_out[addr][12]`, `net22444`, `net31437`, `net53747`, `net56468`,
`net73273` (2 pins), `net75894`, `net84126` (2 pins), `net84183`. 8 of 10 are
buffer-generated nets. Worst checked: `net84126` with partial side-area ratios
**1520.89** (3.8x the limit) and **606.06**.

Diagnosis: diode repair fixed 99.8% of violations; the rest are long routed wires where no
diode could be placed (routing usage 53.8%, met2 68.6%). Magic DRC does not check antenna
ratios, so these are not in the DRC count. Possible fix before tapeout:
raise `GRT_ANTENNA_REPAIR_ITERS` (3 -> 10) and `GRT_ANTENNA_REPAIR_MARGIN`, or allow
jumper insertion, then rerun routing -> RCX -> signoff (~14 h+). Not done this week.

### 2. Setup at the slow corner
`*-openroad-stapostpnr/summary.rpt`: setup positive at all TT/FF corners (worst TT
+24.02 ns, FF +33.68 ns); worst SS setup **-3.6029 ns** (max_ss_100C_1v60, 53 paths;
140 across all SS corners). Hold: 0 violations at all 9 corners (worst +0.0159 ns,
max_ff). Achieved period at SS = 50 + 3.6029 = **53.6029 ns (~18.7 MHz)** - recorded
as real speed per the manual, not a failure.

### 3. Electrical (slew/cap) at the slow corner
summary.rpt at max_ss_100C_1v60: 2,052 max-cap and 222,429 max-slew violations
(fewer at TT/FF, e.g. nom_ff 397 / 7,499). Not a signoff failure; would need more
buffering if Lab 11 requires clean electrical checks.

### 4. Hold margin warning during post-CTS repair
`[RSZ-0064] Unable to repair all hold checks within margin.` (job 735964). Final signoff
shows 0 hold violations, so no ff_n40C hold waiver is needed.
