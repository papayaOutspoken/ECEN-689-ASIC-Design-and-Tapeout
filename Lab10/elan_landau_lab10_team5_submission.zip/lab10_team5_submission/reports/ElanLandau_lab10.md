# Lab 10 individual report  (copy as reports/<your_name>.md - one per member)
Name: Elan landau
NetID: 237007971
Team: 5

## 1. What I personally did in this lab
<!-- (2-5 sentences. Be specific: which steps you drove, what you typed/read.) -->

Made github for group's files.

Told group again to run `srun --qos=olympus-academic --pty bash -i` so olympus not slow.

Read "staff" run
```bash
E=/mnt/nfs-scratch/ecen-689-nowka/docs/example_run
grep -hA10 -i "Final congestion report" $E/*globalrouting/openroad-globalrouting.log
grep -icE "violation" $E/*checkantennas*/*.log
grep -i "Total wire length" $E/*-openroad-detailedrouting/*.log | head -2
```

got

```
bash-4.4$ E=/mnt/nfs-scratch/ecen-689-nowka/docs/example_run
bash-4.4$ grep -hA10 -i "Final congestion report" $E/*globalrouting/openroad-globalrouting.log
Total wire lengt[INFO GRT-0096] Final congestion report:
Layer         Resource        Demand        Usage (%)    Max H / Max V / Total Overflow
---------------------------------------------------------------------------------------
li1                  0             0            0.00%             0 /  0 /  0
met1           1274032          4092            0.32%             0 /  0 /  0
met2           1211163          3463            0.29%             0 /  0 /  0
met3            867456          1148            0.13%             0 /  0 /  0
met4            555188             0            0.00%             0 /  0 /  0
met5            130302             0            0.00%             0 /  0 /  0
---------------------------------------------------------------------------------------
Total          4038141          8703            0.22%             0 /  0 /  0
bash-4.4$ grep -icE "violation" $E/*checkantennas*/*.log
h" $E/*-openroad-detailedrouting/*.log | head -2/mnt/nfs-scratch/ecen-689-nowka/docs/example_run/40-openroad-checkantennas/openroad-checkantennas.log:2
/mnt/nfs-scratch/ecen-689-nowka/docs/example_run/46-openroad-checkantennas-1/openroad-checkantennas-1.log:2
bash-4.4$ grep -i "Total wire length" $E/*-openroad-detailedrouting/*.log | head -2
Total wire length = 57175 um.
Total wire length on LAYER li1 = 0 um.
```

Ran through the clock-tree synthesis. Hit hold warning. Changed config.yaml to try to prevent.  Re-ran. Maybe fixed?

Ran through routing and sign-off. Took long time, much space, no errors I can see.



## 2. Problems I encountered

1. Most of the detailed placement runs didn't work.
2. Hold violation failed in `flow.log`, `warning.log`, and `33-openroad-resizertimingpostcts/openroad-resizertimingpostcts.log`: `[RSZ-0064] Unable to repair all hold checks within margin.`

## 3. How each problem was resolved
1. Used the one detailed placement run that actually worked. Found it by running the gui to see which detailed placements still looked right.
2. At line 48 in config.yaml insert
```yaml
 PL_RESIZER_FIX_HOLD_FIRST: true # attempt to fix hold violation
 PL_RESIZER_HOLD_MAX_BUFFER_PCT: 60 # attempt to fix hold violation
```
